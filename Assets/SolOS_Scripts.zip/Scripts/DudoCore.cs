using System;
using System.Collections.Generic;
using UnityEngine;

namespace DudoGame
{
    [Serializable]
    public class Bid
    {
        public int quantity;
        public int value; // 1=Aces, 2–6=normal faces

        public Bid(int q, int v)
        {
            quantity = q;
            value = v;
        }

        public bool IsValid()
        {
            return quantity > 0 && value >= 1 && value <= 6;
        }

        public override string ToString()
        {
            string valueName = (value == 1) ? "Aces" : value.ToString();
            return $"{quantity} {valueName}";
        }
    }

    [Serializable]
    public class Player
    {
        public string playerName;
        public List<int> dice;
        public int diceCount;
        public bool isAI;
        public bool eliminated;

        public Player(string name, int startingDice, bool ai)
        {
            playerName = name;
            diceCount = startingDice;
            isAI = ai;
            eliminated = false;
            dice = new List<int>();
        }

        public void RollDice()
        {
            dice.Clear();
            for (int i = 0; i < diceCount; i++)
                dice.Add(UnityEngine.Random.Range(1, 7));
        }

        public void LoseDie()
        {
            diceCount--;
            if (diceCount <= 0)
            {
                eliminated = true;
                diceCount = 0;
            }
        }
    }

    public static class DudoRules
    {
        // Count how many dice match the bid (aces are wild for non-ace bids)
        public static int CountDice(List<Player> players, int value)
        {
            int count = 0;
            foreach (Player player in players)
            {
                if (player.eliminated) continue;
                foreach (int die in player.dice)
                {
                    if (value == 1)
                    {
                        if (die == 1) count++;
                    }
                    else
                    {
                        if (die == value || die == 1) count++;
                    }
                }
            }
            return count;
        }

        // Validation with table maximum (totalDiceInPlay) awareness
        public static (bool valid, string reason) IsValidBid(Bid currentBid, Bid newBid, int totalDiceInPlay = -1)
        {
            if (!newBid.IsValid())
                return (false, "Invalid bid values");

            // Absolute cap: cannot exceed the total dice in play
            if (totalDiceInPlay > 0 && newBid.quantity > totalDiceInPlay)
                return (false, $"Cannot bid more than the table maximum of {totalDiceInPlay}");

            // First bid cannot be aces
            if (currentBid == null)
            {
                if (newBid.value == 1)
                    return (false, "First bid cannot be Aces");
                return (true, "");
            }

            int prevQty = currentBid.quantity;
            int prevVal = currentBid.value;
            int newQty  = newBid.quantity;
            int newVal  = newBid.value;

            // If quantity is already at the table max, the only legal raise is a higher face (same qty)
            if (totalDiceInPlay > 0 && prevQty >= totalDiceInPlay)
            {
                if (newQty != prevQty)
                    return (false, $"Quantity is already at the table maximum ({totalDiceInPlay}); you must increase the face value");
                if (newVal <= prevVal)
                    return (false, $"Must increase face value above {prevVal}");
                return (true, "");
            }

            // Converting TO aces from non-aces
            if (newVal == 1 && prevVal != 1)
            {
                int minAces = Mathf.CeilToInt(prevQty / 2f) + 1; // one above half
                if (newQty < minAces)
                    return (false, $"Must bid at least {minAces} Aces (one above half of {prevQty})");
                return (true, "");
            }

            // Converting FROM aces to non-aces
            if (newVal != 1 && prevVal == 1)
            {
                int minQty = prevQty * 2 + 1;
                if (newQty < minQty)
                {
                    // Exception: allow exactly the table maximum even if below 2x+1
                    if (totalDiceInPlay > 0 && newQty == totalDiceInPlay)
                        return (true, "");
                    return (false, $"Must bid at least {minQty} (double {prevQty} plus 1), or use the table maximum of {totalDiceInPlay}");
                }
                return (true, "");
            }

            // Same face (aces->aces or same non-ace face): quantity must strictly increase
            if (newVal == prevVal)
            {
                if (newQty <= prevQty)
                    return (false, $"Must increase quantity above {prevQty}");
                return (true, "");
            }

            // Both non-aces, different values
            if (newVal != 1 && prevVal != 1)
            {
                if (newQty > prevQty) return (true, "");              // raising quantity OK
                if (newQty == prevQty && newVal > prevVal) return (true, ""); // same qty, higher face OK

                if (newQty == prevQty && newVal <= prevVal)
                    return (false, $"Must increase face value above {prevVal}");

                if (newQty < prevQty && newVal > prevVal)
                    return (false, $"Cannot decrease quantity below {prevQty} when increasing face value");

                return (false, $"Must increase quantity above {prevQty} or (with same quantity) increase face value above {prevVal}");
            }

            return (false, "Invalid bid");
        }
    }

    public class DudoGameManager
    {
        public List<Player> players;
        public int currentPlayerIndex;
        public Bid currentBid;
        public int lastBidderIndex;
        public bool roundActive;
        public List<string> gameLog;
        private EnemyProfile _enemy;

        public DudoGameManager(string playerName, int startingDice = 5)
        {
            players = new List<Player>
            {
                new Player(playerName, startingDice, false),
                new Player("AI", startingDice, true)
            };
            gameLog = new List<string>();
            currentPlayerIndex = 0;
            roundActive = false;
        }
        
        public void SetEnemyProfile(EnemyProfile profile)
        {
            _enemy = profile;
        }

        public void StartNewRound()
        {
            currentBid = null;
            lastBidderIndex = -1;
            roundActive = true;

            foreach (Player player in players)
                if (!player.eliminated) player.RollDice();

            AddLog($"New round started. {players[currentPlayerIndex].playerName} goes first.");
        }

        public void MakeBid(int quantity, int value)
        {
            currentBid = new Bid(quantity, value);
            lastBidderIndex = currentPlayerIndex;
            AddLog($"{players[currentPlayerIndex].playerName} bids {currentBid}");
            NextTurn();
        }

        public void CallBid()
        {
            if (currentBid == null) return;

            roundActive = false;
            int actual = DudoRules.CountDice(players, currentBid.value);
            int bidder = lastBidderIndex;
            int caller = currentPlayerIndex;

            string valueName = (currentBid.value == 1) ? "Aces" : currentBid.value.ToString();
            AddLog($"{players[caller].playerName} calls! Checking...");
            AddLog($"Actual count: {actual} {valueName}");

            int loser = (actual >= currentBid.quantity) ? caller : bidder;
            AddLog((actual >= currentBid.quantity)
                ? $"Bid was correct! {players[caller].playerName} loses a die!"
                : $"Bid was wrong! {players[bidder].playerName} loses a die!");

            players[loser].LoseDie();
            currentPlayerIndex = loser; // Loser starts next round
        }

        public void SpotOn()
        {
            if (currentBid == null) return;

            roundActive = false;
            int actual = DudoRules.CountDice(players, currentBid.value);
            int caller = currentPlayerIndex;

            string valueName = (currentBid.value == 1) ? "Aces" : currentBid.value.ToString();
            AddLog($"{players[caller].playerName} calls Spot On! Checking...");
            AddLog($"Actual count: {actual} {valueName}");

            if (actual == currentBid.quantity)
            {
                AddLog("Spot On! No one loses dice.");
                currentPlayerIndex = lastBidderIndex; // declarer starts
            }
            else
            {
                AddLog($"Wrong! {players[caller].playerName} loses a die!");
                players[caller].LoseDie();
                currentPlayerIndex = caller; // caller starts next
            }
        }

        public bool IsGameOver()
        {
            int active = 0;
            foreach (Player p in players) if (!p.eliminated) active++;
            return active <= 1;
        }

        public Player GetWinner()
        {
            foreach (Player p in players) if (!p.eliminated) return p;
            return null;
        }

        private void NextTurn()
        {
            do
            {
                currentPlayerIndex = (currentPlayerIndex + 1) % players.Count;
            } while (players[currentPlayerIndex].eliminated);
        }

        public void AddLog(string message)
        {
            gameLog.Insert(0, message);
            if (gameLog.Count > 20) gameLog.RemoveAt(20);
        }

        // AI Decision Making
        // AI Decision Making
public (string action, Bid bid) GetAIDecision()
{
    int maxDice = GetTotalDiceInPlay();

    if (currentBid != null && currentBid.quantity >= maxDice && currentBid.value >= 6)
        return ("call", null);

    float callBase  = (_enemy != null) ? _enemy.callDudoBase  : 0.15f;
    float spotBase  = (_enemy != null) ? _enemy.spotOnBase    : 0.10f;
    float raiseBias = (_enemy != null) ? _enemy.raiseQuantityBias : 0.60f;
    float aggr      = (_enemy != null) ? _enemy.aggression    : 0.50f;

    if (currentBid == null)
    {
        int q = Mathf.Clamp(UnityEngine.Random.Range(1, 4), 1, Mathf.Max(1, maxDice));
        int v = UnityEngine.Random.Range(2, 7);
        return ("raise", new Bid(q, v));
    }

    float r = UnityEngine.Random.value;
    if (r < callBase) return ("call", null);
    if (r < callBase + spotBase) return ("spoton", null);

    Bid candidate = GenerateAIBidWithBias(maxDice, raiseBias, aggr);
    if (candidate != null) return ("raise", candidate);

    return ("call", null);
}

private Bid GenerateAIBidWithBias(int maxDice, float raiseQuantityBias, float aggression)
{
    if (currentBid == null)
        return new Bid(
            Mathf.Clamp(UnityEngine.Random.Range(1, 4), 1, Mathf.Max(1, maxDice)),
            UnityEngine.Random.Range(2, 7)
        );

    if (currentBid.quantity >= maxDice)
    {
        if (currentBid.value < 6)
        {
            var b = new Bid(currentBid.quantity, currentBid.value + 1);
            var v = DudoRules.IsValidBid(currentBid, b, maxDice);
            return v.valid ? b : null;
        }
        return null;
    }

    Bid qtyRaise = null;
    Bid faceRaise = null;

    if (currentBid.quantity + 1 <= maxDice)
        qtyRaise = new Bid(currentBid.quantity + 1, currentBid.value);

    if (currentBid.value < 6)
        faceRaise = new Bid(currentBid.quantity, currentBid.value + 1);

    Bid toAces = null;
    if (currentBid.value != 1)
    {
        int aceQty = Mathf.CeilToInt(currentBid.quantity / 2f) + 1;
        aceQty = Mathf.Min(aceQty, maxDice);
        toAces = new Bid(aceQty, 1);
    }

    Bid fromAces = null;
    if (currentBid.value == 1)
    {
        int nonAceQty = currentBid.quantity * 2 + 1;
        nonAceQty = Mathf.Min(nonAceQty, maxDice);
        fromAces = new Bid(nonAceQty, UnityEngine.Random.Range(2, 7));
    }

    Bid[] preferenceOrder;
    if (UnityEngine.Random.value < raiseQuantityBias)
        preferenceOrder = new Bid[] { qtyRaise, faceRaise, toAces, fromAces };
    else
        preferenceOrder = new Bid[] { faceRaise, qtyRaise, toAces, fromAces };

    foreach (var b in preferenceOrder)
    {
        if (b == null) continue;
        var v = DudoRules.IsValidBid(currentBid, b, maxDice);
        if (v.valid) return b;
    }

    return null;
}


        private int GetTotalDiceInPlay()
        {
            int total = 0;
            foreach (var p in players) if (!p.eliminated) total += p.diceCount;
            return total;
        }
    }
}
